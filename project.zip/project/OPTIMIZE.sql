OPTIMIZE shivam_catalog_project.capstone_retail_shivam.gold_sales_region
ZORDER BY (Region, OrderDate);

OPTIMIZE shivam_catalog_project.capstone_retail_shivam.gold_anomaly_trends
ZORDER BY (StoreID, DeviceType);

OPTIMIZE shivam_catalog_project.capstone_retail_shivam.gold_conversion_impact
ZORDER BY (StoreID);

OPTIMIZE shivam_catalog_project.capstone_retail_shivam.gold_store_tiers
ZORDER BY (StoreID);

OPTIMIZE shivam_catalog_project.capstone_retail_shivam.gold_weighted_sales_anomalies
ZORDER BY (StoreID);
