# Databricks notebook source
# =========================================
# Bronze → Silver → Gold with Event Hub Integration
# =========================================
 
from dlt import table, read
import pyspark.sql.functions as F
from pyspark.sql.types import *
 
# ================================
# 1️⃣ Bronze Layer: Schema & CSV
# ================================
iot_schema = StructType([
    StructField("OrderID", StringType(), True),
    StructField("CustomerID", StringType(), True),
    StructField("Region", StringType(), True),
    StructField("StoreID", StringType(), True),
    StructField("Product", StringType(), True),
    StructField("Quantity", IntegerType(), True),
    StructField("UnitPrice", DoubleType(), True),
    StructField("SalesAmount", DoubleType(), True),
    StructField("OrderTime", StringType(), True),
    StructField("DeviceType", StringType(), True),
    StructField("Temperature", DoubleType(), True),
    StructField("DeviceStatus", StringType(), True),
    StructField("AnomalyFlag", IntegerType(), True),
    StructField("AnomalyType", StringType(), True)
])
 
raw_path = "abfss://capstoneproject@vaishnavidata.dfs.core.windows.net/incoming/"
schema_path = "abfss://capstoneproject@vaishnavidata.dfs.core.windows.net/dlt_schemas/bronze_orders_vaishnavi"
 
@table(
    name="retail_catalog_vaishnavi.bronze.bronze_orders_csv",
    comment="Bronze table - raw IoT CSV"
)
def bronze_orders_csv():
    return (
        spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", "csv")
            .option("header", True)
            .option("cloudFiles.schemaLocation", schema_path)
            .schema(iot_schema)
            .load(raw_path)
            .withColumn("OrderTime", F.to_timestamp("OrderTime"))
    )
 
# ================================
# 2️⃣ Bronze Layer: Event Hub IoT
# ================================
eventhub_connection_string = "Endpoint=sb://vaishnavievent.servicebus.windows.net/;SharedAccessKeyName=manage;SharedAccessKey=FKKqGhzAyDEqYXgNZvxzpYat2gUjW1VTS+AEhAIkesY=;EntityPath=event-vm"
consumer_group = "$Default"
 
ehConf = {
    'eventhubs.connectionString': eventhub_connection_string,
    'eventhubs.consumerGroup': consumer_group,
    'eventhubs.startingPosition': '@latest'
}
 
@table(
    name="retail_catalog_vaishnavi.bronze.bronze_orders_eventhub",
    comment="Bronze table - live IoT data from Event Hub"
)
def bronze_orders_eventhub():
    df = spark.readStream \
        .format("eventhubs") \
        .options(**ehConf) \
        .load()
    # Event Hub body is bytes → convert to string → parse JSON
    df1 = df.selectExpr("cast(body as string) as json_string")
    df_parsed = df1.select(F.from_json(F.col("json_string"), iot_schema).alias("data")).select("data.*")
    return df_parsed.withColumn("OrderTime", F.to_timestamp("OrderTime"))
 
# ================================
# 3️⃣ Unified Bronze Table
# ================================
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.bronze_orders",
    comment="Unified Bronze table (CSV + Event Hub)"
)
def bronze_orders():
    df_csv = read("hetul_project01_catalog.capstone_retail_hetul.bronze_orders_csv")
    df_eh = read("hetul_project01_catalog.capstone_retail_hetul.bronze_orders_eventhub")
    return df_csv.unionByName(df_eh)
 
# ================================
# 4️⃣ Silver Layer
# ================================
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.silver_orders",
    comment="Silver layer: cleaned and deduplicated IoT orders with anomaly handling"
)
def silver_orders():
    orders = read("hetul_project01_catalog.capstone_retail_hetul.bronze_orders")
 
    orders = (
        orders.withColumn("Quantity", F.col("Quantity").cast(IntegerType()))
              .withColumn("UnitPrice", F.col("UnitPrice").cast(DoubleType()))
              .withColumn("SalesAmount", F.col("SalesAmount").cast(DoubleType()))
              .withColumn("Temperature", F.col("Temperature").cast(DoubleType()))
              .withColumn("OrderTime", F.to_timestamp("OrderTime", "M/d/yyyy H:mm"))
    )
 
    orders = orders.dropDuplicates(["OrderID"])
 
    orders = orders.withColumn(
        "AnomalyType",
        F.when((F.col("AnomalyFlag") == 1) & (F.col("AnomalyType").isNull()), "Unknown")
         .when((F.col("AnomalyFlag") == 1) & (F.col("AnomalyType") == ""), "Unknown")
         .otherwise(F.col("AnomalyType"))
    )
 
    orders = (
        orders.withColumn("IsAnomaly", F.col("AnomalyFlag") == 1)
              .withColumn("DeviceStatus", F.upper(F.col("DeviceStatus")))
              .withColumn("NormalizedStoreID", F.upper(F.col("StoreID")))
              .withColumn("NormalizedProduct", F.upper(F.col("Product")))
    )
 
    return orders
 
# ================================
# 5️⃣ Gold Layer
# ================================
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.gold_sales_region",
    comment="Daily & Monthly Sales per Region"
)
def gold_sales_region():
    return (
        read("hetul_project01_catalog.capstone_retail_hetul.silver_orders")
        .withColumn("OrderDate", F.to_date("OrderTime", "M/d/yyyy H:mm"))
        .withColumn("YearMonth", F.date_format("OrderDate", "yyyy-MM"))
        .groupBy("Region", "OrderDate", "YearMonth")
        .agg(F.sum("SalesAmount").alias("TotalSales"))
    )
 
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.gold_anomaly_trends",
    comment="Device Anomaly Trend per Store"
)
def gold_anomaly_trends():
    return (
        read("hetul_project01_catalog.capstone_retail_hetul.silver_orders")
        .withColumn("OrderDate", F.to_date("OrderTime", "M/d/yyyy H:mm"))
        .groupBy("StoreID", "OrderDate", "DeviceType", "AnomalyType")
        .agg(F.count("*").alias("AnomalyCount"))
    )
 
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.gold_conversion_impact",
    comment="Conversion rate impact of device failures"
)
def gold_conversion_impact():
    df = read("hetul_project01_catalog.capstone_retail_hetul.silver_orders")
    total_orders = df.groupBy("StoreID").agg(F.count("*").alias("TotalOrders"))
    failed_orders = (
        df.filter(df.AnomalyFlag == 1)
          .groupBy("StoreID")
          .agg(F.count("*").alias("FailedOrders"))
    )
    return (
        total_orders.join(failed_orders, "StoreID", "left")
        .withColumn("FailedOrders", F.coalesce(F.col("FailedOrders"), F.lit(0)))
        .withColumn("FailureRate", F.col("FailedOrders") / F.col("TotalOrders"))
    )
 
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.gold_store_tiers",
    comment="Store tiers based on total sales (High / Medium / Low performers)"
)
def gold_store_tiers():
    df = (
        read("hetul_project01_catalog.capstone_retail_hetul.silver_orders")
        .groupBy("StoreID")
        .agg(F.sum("SalesAmount").alias("TotalSales"))
    )
    return (
        df.withColumn(
            "StoreTier",
            F.when(F.col("TotalSales") > 100000, "High")
             .when(F.col("TotalSales") > 50000, "Medium")
             .otherwise("Low")
        )
    )
 
@table(
    name="hetul_project01_catalog.capstone_retail_hetul.gold_weighted_sales_anomalies",
    comment="Weighted average of sales vs anomalies per store"
)
def gold_weighted_sales_anomalies():
    df = read("hetul_project01_catalog.capstone_retail_hetul.silver_orders")
    return (
        df.groupBy("StoreID")
        .agg(
            F.sum("SalesAmount").alias("TotalSales"),
            F.sum(F.when(F.col("AnomalyFlag") == 1, 1).otherwise(0)).alias("TotalAnomalies")
        )
        .withColumn("SalesPerAnomaly",
            F.when(F.col("TotalAnomalies") > 0, F.col("TotalSales") / F.col("TotalAnomalies"))
             .otherwise(F.lit(None))
        )
    )

# COMMAND ----------

from dlt import table
import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *

# Set Event Hub connection
%python
# Set Event Hub connection
event_hub_connection_string = (
    "sb://shivameventhub.servicebus.windows.net/;"
    "SharedAccessKeyName=shivam_manage;"
    "SharedAccessKey=FUKQoBovwGWYqgfxmhLLuTBe2XPh+Rw9i+AEhCvSdmw=;"
    "EntityPath=shivamevent"
)  # 🔐 Replace securely

eh_conf = {
    'eventhubs.connectionString': event_hub_connection_string
}

# Define streaming schema based on your IoT structure
iot_schema = StructType([
    StructField("OrderID", StringType(), True),
    StructField("CustomerID", StringType(), True),
    StructField("Region", StringType(), True),
    StructField("StoreID", StringType(), True),
    StructField("Product", StringType(), True),
    StructField("Quantity", IntegerType(), True),
    StructField("UnitPrice", DoubleType(), True),
    StructField("SalesAmount", DoubleType(), True),
    StructField("OrderTime", StringType(), True),  # Will cast to timestamp later
    StructField("DeviceType", StringType(), True),
    StructField("Temperature", DoubleType(), True),
    StructField("DeviceStatus", StringType(), True),
    StructField("AnomalyFlag", IntegerType(), True),
    StructField("AnomalyType", StringType(), True)
])


# COMMAND ----------

@dlt.table(
    name="shivam_catalog_project.capstone_retail_shivam.bronze_orders",
    comment="Bronze streaming table - raw data from Event Hubs"
)
def bronze_orders():
    raw_stream = spark.readStream \
        .format("eventhubs") \
        .options(**eh_conf) \
        .load()

    # Decode JSON from body
    json_df = raw_stream \
        .selectExpr("cast(body as string) as json") \
        .select(from_json("json", iot_schema).alias("data")) \
        .select("data.*")

    return json_df


# COMMAND ----------

@dlt.table(
    comment="Silver table - typed and cleaned streaming data",
    partition_cols=["Region", "OrderDate"]
)
def silver_orders():
    df = dlt.read_stream("shivam_catalog_project.capstone_retail_shivam.bronze_orders")
    return (
        df.withColumn("Quantity", col("Quantity").cast("int"))
          .withColumn("UnitPrice", col("UnitPrice").cast("double"))
          .withColumn("OrderTime", to_timestamp("OrderTime"))
          .withColumn("OrderDate", to_date("OrderTime"))
    )


# COMMAND ----------

@dlt.table(
    comment="Gold table - sales aggregates by region"
)
def gold_sales_region():
    df = dlt.read_stream("silver_orders")
    return (
        df.withColumn("YearMonth", date_format("OrderDate", "yyyy-MM"))
          .groupBy("Region", "OrderDate", "YearMonth")
          .agg(sum("SalesAmount").alias("TotalSales"))
    )


# COMMAND ----------

@dlt.table(
    comment="Gold table - device anomaly trends per store"
)
def gold_anomaly_trends():
    df = dlt.read_stream("silver_orders")
    return (
        df.groupBy("StoreID", "OrderDate", "DeviceType", "AnomalyType")
          .agg(count("*").alias("AnomalyCount"))
    )


# COMMAND ----------

@dlt.table(
    comment="Gold table - conversion impact of device failures"
)
def gold_conversion_impact():
    df = dlt.read_stream("silver_orders")
    total = df.groupBy("StoreID").agg(count("*").alias("TotalOrders"))
    failed = df.filter(col("AnomalyFlag") == 1).groupBy("StoreID").agg(count("*").alias("FailedOrders"))

    return (
        total.join(failed, "StoreID", "left")
             .withColumn("FailedOrders", coalesce(col("FailedOrders"), lit(0)))
             .withColumn("FailureRate", col("FailedOrders") / col("TotalOrders"))
    )


# COMMAND ----------

@dlt.table(
    comment="Gold table - store performance tiers"
)
def gold_store_tiers():
    df = dlt.read_stream("silver_orders")
    return (
        df.groupBy("StoreID")
          .agg(sum("SalesAmount").alias("TotalSales"))
          .withColumn(
              "StoreTier",
              when(col("TotalSales") > 100000, "High")
              .when(col("TotalSales") > 50000, "Medium")
              .otherwise("Low")
          )
    )


# COMMAND ----------

@dlt.table(
    comment="Gold table - weighted sales vs anomalies"
)
def gold_weighted_sales_anomalies():
    df = dlt.read_stream("silver_orders")
    return (
        df.groupBy("StoreID")
          .agg(
              sum("SalesAmount").alias("TotalSales"),
              sum(when(col("AnomalyFlag") == 1, 1).otherwise(0)).alias("TotalAnomalies")
          )
          .withColumn(
              "SalesPerAnomaly",
              when(col("TotalAnomalies") > 0, col("TotalSales") / col("TotalAnomalies"))
              .otherwise(lit(None))
          )
    )
